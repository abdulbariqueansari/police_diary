<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../middleware/auth.php';

class AuthController {
    public function login($input) {
        $conn = getDBConnection();
        $username = isset($input['username']) ? trim($input['username']) : '';
        $password = isset($input['password']) ? trim($input['password']) : '';

        sleep(1); // Prevent brute force

        if (empty($username) || empty($password)) {
            sendResponse(400, 'error', 'Username and password required');
        }

        $stmt = $conn->prepare("SELECT id, username, password, full_name, role, status FROM users WHERE username = ? LIMIT 1");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if ($user['status'] !== 'active') {
                sendResponse(403, 'error', 'Account is inactive');
            }
            if (password_verify($password, $user['password'])) {
                $conn->query("UPDATE users SET last_login = NOW() WHERE id = " . $user['id']);
                $token = generateToken($user['id'], $user['role']);
                unset($user['password']);
                
                sendResponse(200, 'success', 'Login successful', [
                    'token' => $token,
                    'user' => $user
                ]);
            } else {
                sendResponse(401, 'error', 'Invalid credentials');
            }
        } else {
            sendResponse(404, 'error', 'User not found');
        }
        $stmt->close();
    }
}
?>
