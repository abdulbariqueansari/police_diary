<?php
require_once __DIR__ . '/../config/database.php';

class DiaryController {
    
    public function getEntries($input, $user_id) {
        $conn = getDBConnection();
        $page = isset($input['page']) ? max(1, intval($input['page'])) : 1;
        $limit = isset($input['limit']) ? max(1, intval($input['limit'])) : 20;
        $offset = ($page - 1) * $limit;

        $stmt = $conn->prepare("SELECT id, entry_date, entry_time, report, orders_remarks, created_at FROM diary_entries WHERE user_id = ? ORDER BY entry_date DESC, entry_time DESC LIMIT ? OFFSET ?");
        $stmt->bind_param("iii", $user_id, $limit, $offset);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $entries = [];
        while ($row = $result->fetch_assoc()) {
            $row['report'] = htmlspecialchars($row['report']);
            $row['orders_remarks'] = htmlspecialchars($row['orders_remarks']);
            $entries[] = $row;
        }
        
        $countStmt = $conn->prepare("SELECT COUNT(*) as total FROM diary_entries WHERE user_id = ?");
        $countStmt->bind_param("i", $user_id);
        $countStmt->execute();
        $total = $countStmt->get_result()->fetch_assoc()['total'];
        
        sendResponse(200, 'success', 'Entries fetched', [
            'entries' => $entries,
            'pagination' => [
                'current_page' => $page,
                'limit' => $limit,
                'total_items' => $total,
                'total_pages' => ceil($total / $limit)
            ]
        ]);
    }

    public function addEntry($input, $user_id) {
        $conn = getDBConnection();
        $date = isset($input['date']) && !empty($input['date']) ? trim($input['date']) : date('Y-m-d');
        $time = isset($input['time']) && !empty($input['time']) ? trim($input['time']) : date('H:i:s');
        $report = isset($input['report']) ? trim(strip_tags($input['report'])) : '';
        $orders = isset($input['orders']) ? trim(strip_tags($input['orders'])) : '';

        if (empty($report)) sendResponse(400, 'error', 'Report content is required');

        $stmt = $conn->prepare("INSERT INTO diary_entries (user_id, entry_date, entry_time, report, orders_remarks) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $user_id, $date, $time, $report, $orders);
        if ($stmt->execute()) {
            sendResponse(201, 'success', 'Entry added successfully', ['id' => $conn->insert_id]);
        } else {
            sendResponse(500, 'error', 'Failed to add entry. Database error.');
        }
        $stmt->close();
    }
}
?>
