<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';

function checkRateLimit($user_ip) {
    $conn = getDBConnection();
    $max_requests = 100;

    $conn->query("CREATE TABLE IF NOT EXISTS api_rate_limits (
        ip_address VARCHAR(45) PRIMARY KEY,
        hits INT DEFAULT 1,
        last_request TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    $conn->query("DELETE FROM api_rate_limits WHERE last_request < NOW() - INTERVAL 1 MINUTE");

    $rate_stmt = $conn->prepare("INSERT INTO api_rate_limits (ip_address) VALUES (?) ON DUPLICATE KEY UPDATE hits = hits + 1");
    $rate_stmt->bind_param("s", $user_ip);
    $rate_stmt->execute();

    $check_stmt = $conn->prepare("SELECT hits FROM api_rate_limits WHERE ip_address = ?");
    $check_stmt->bind_param("s", $user_ip);
    $check_stmt->execute();
    $hits = $check_stmt->get_result()->fetch_assoc()['hits'];

    if ($hits > $max_requests) {
        sendResponse(429, 'error', 'Too Many Requests. Please slow down.');
    }
}
?>
