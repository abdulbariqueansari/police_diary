<?php
require_once __DIR__ . '/../../../config.php';

// Reuse existing connection from config.php or return it
function getDBConnection() {
    global $conn;
    return $conn;
}
?>
