<?php
define('API_KEY', 'pd_mobile_app_v2_ultra_secure_998877');
define('JWT_SECRET', 'police_diary_secure_super_secret_key_2026_V2!');
?>
