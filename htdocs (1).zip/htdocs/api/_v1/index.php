<?php
require_once __DIR__ . '/../middleware/headers.php';
require_once __DIR__ . '/../middleware/rate_limit.php';
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../controllers/AuthController.php';
require_once __DIR__ . '/../controllers/DiaryController.php';

function sendResponse($status_code, $status, $message, $data = null) {
    http_response_code($status_code);
    $response = ['status' => $status, 'message' => $message];
    if ($data !== null) $response['data'] = $data;
    echo json_encode($response);
    exit;
}

setSecureHeaders();
validateApiKey();
checkRateLimit($_SERVER['REMOTE_ADDR']);

$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE);
if (empty($input)) {
    $input = $_POST;
}

$action = isset($input['action']) ? trim($input['action']) : (isset($_GET['action']) ? trim($_GET['action']) : '');

switch ($action) {
    case 'login':
        $auth = new AuthController();
        $auth->login($input);
        break;

    case 'get_entries':
        $payload = verifyToken();
        if (!$payload) sendResponse(401, 'error', 'Unauthorized');
        $diary = new DiaryController();
        $diary->getEntries($input, $payload['user_id']);
        break;

    case 'add_entry':
        $payload = verifyToken();
        if (!$payload) sendResponse(401, 'error', 'Unauthorized');
        $diary = new DiaryController();
        $diary->addEntry($input, $payload['user_id']);
        break;

    default:
        sendResponse(400, 'error', 'Invalid action');
        break;
}
?>
