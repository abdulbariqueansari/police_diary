<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

define('DB_HOST', 'sql212.ezyro.com');
define('DB_USER', 'ezyro_41931463');
define('DB_PASS', 'Abdul@1994');
define('DB_NAME', 'ezyro_41931463_wbpsi_pd');

define('ROOT_PATH', __DIR__);

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
date_default_timezone_set('Asia/Kolkata');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
